from . import conftests

class TestGhost:

    def test_ghost_base(self):
        assert 1 == 1
